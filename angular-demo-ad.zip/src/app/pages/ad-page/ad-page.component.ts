import { Component } from '@angular/core';

@Component({
  selector: 'app-ad-page',
  imports: [],
  templateUrl: './ad-page.component.html',
  styleUrl: './ad-page.component.scss'
})
export class AdPageComponent {

}
