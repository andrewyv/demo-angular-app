import { Component } from '@angular/core';

@Component({
  selector: 'app-post-ad-page',
  imports: [],
  templateUrl: './post-ad-page.component.html',
  styleUrl: './post-ad-page.component.scss'
})
export class PostAdPageComponent {

}
