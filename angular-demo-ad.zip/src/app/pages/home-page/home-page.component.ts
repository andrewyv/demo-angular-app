import { Component } from '@angular/core';
import {Button} from 'primeng/button';

@Component({
  selector: 'app-home-page',
  imports: [
    Button
  ],
  templateUrl: './home-page.component.html',
  styleUrl: './home-page.component.scss'
})
export class HomePageComponent {

}
