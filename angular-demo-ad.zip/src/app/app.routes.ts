import { Routes } from '@angular/router';
import {HomePageComponent} from './pages/home-page/home-page.component';
import {PostAdPageComponent} from './pages/post-ad-page/post-ad-page.component';
import {CategoryPageComponent} from './pages/category-page/category-page.component';
import {LoginPageComponent} from './pages/auth/login-page/login-page.component';
import {RegisterPageComponent} from './pages/auth/register-page/register-page.component';
import {AdPageComponent} from './pages/ad-page/ad-page.component';


export const routes: Routes = [
    { path: '', component: HomePageComponent},

    // Ad routes
    { path: 'ad/:guid', component: AdPageComponent},
    { path: 'post', component: PostAdPageComponent},

    // Category
    { path: 'category/:slug', component: CategoryPageComponent},

    // Auth routes
    { path: 'login', component: LoginPageComponent},
    { path: 'register', component: RegisterPageComponent},

    // // Not found
    // { path: '**', component: NotFoundComponent }
];
