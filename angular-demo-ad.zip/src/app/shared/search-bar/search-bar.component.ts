import { Component } from '@angular/core';
import {InputText} from 'primeng/inputtext';
import {Button} from 'primeng/button';
import {AutoComplete} from 'primeng/autocomplete';

@Component({
  selector: 'app-search-bar',
  imports: [
    InputText,
    Button,
    AutoComplete
  ],
  templateUrl: './search-bar.component.html',
  styleUrl: './search-bar.component.scss'
})
export class SearchBarComponent {

}
