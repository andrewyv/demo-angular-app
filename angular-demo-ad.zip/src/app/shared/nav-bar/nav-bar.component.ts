import { Component } from '@angular/core';
import {Menubar} from 'primeng/menubar';
import {MenuItem} from 'primeng/api';
import {InputText} from 'primeng/inputtext';
import {DropdownModule} from 'primeng/dropdown';
import {ReactiveFormsModule} from '@angular/forms';
import {AutoComplete} from 'primeng/autocomplete';
import {ButtonDirective, ButtonIcon} from 'primeng/button';
import {SearchBarComponent} from '../search-bar/search-bar.component';

@Component({
  selector: 'app-nav-bar',
  imports: [
    Menubar,
    DropdownModule,
    ReactiveFormsModule,
    SearchBarComponent
  ],
  templateUrl: './nav-bar.component.html',
  styleUrl: './nav-bar.component.scss'
})
export class NavBarComponent {
  items: MenuItem[] = [
    {
      label: 'Acasă',
      icon: 'pi pi-home',
      routerLink: '/'
    },
    {
      label: 'Anunțuri',
      icon: 'pi pi-list',
      items: [
        {
          label: 'Toate anunțurile',
          icon: 'pi pi-th-large'
        },
        {
          label: 'Categorii',
          icon: 'pi pi-tags'
        }
      ]
    },
    {
      label: 'Adaugă anunț',
      icon: 'pi pi-plus'
    },
    {
      label: 'Contact',
      icon: 'pi pi-envelope'
    }
  ];
  searchForm: any;
  categories: any;
  filteredLocations: any;

  onSubmit() {

  }

  filterLocation($event: any) {

  }
}
